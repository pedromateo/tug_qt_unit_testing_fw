#ifndef TESTSUITEDESCRIPTOR_H
#define TESTSUITEDESCRIPTOR_H

///
/// \brief Describes all properties for a testsuite binary
struct TestSuiteDescriptor{
    std::string id;
    std::string path;
    std::string description;
};

#endif // TESTSUITEDESCRIPTOR_H
