#ifndef GUI_TESTSUITE_LIBRARY_H
#define GUI_TESTSUITE_LIBRARY_H

#include "gui_testsuite_library_global.h"

class GUI_TESTSUITE_LIBRARYSHARED_EXPORT gui_testsuite_library {
public:
    gui_testsuite_library();
};

#endif // GUI_TESTSUITE_LIBRARY_H
